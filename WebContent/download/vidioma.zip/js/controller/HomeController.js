app.controller('HomeController', function ($scope) {
    var ctrl = this;

    return $scope.HomeController = this;
});
