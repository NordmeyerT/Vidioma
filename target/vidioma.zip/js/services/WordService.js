/**
 * Service loading data from server and providing access
 */
app.factory('WordService', function ($http, LanguageService, $rootScope, $log, CsvService) {
    var service = this;

    var words = {};
    var itemList = [];
    var itemHash = [];

    var node = {};

    var init = function() {
    	$http.get("data/structure.csv").success(function(response) {
    		var structure = CsvService.toObjects(response);
    		for(var i=0; i<structure.length; i++) {
    			var item = {};
    			item.parent = structure[i][0];
    			item.id = structure[i][1];
    			if(item.id) {
        			item.word = item.id;
	    			item.pic = structure[i][2] ? structure[i][2] : "data/pictures/"+item.id+".png";
	    			if(item.parent) {
		    			var parent = itemHash[item.parent];
		    			if(parent) {
		    				parent.hasChildren = true;
		    			}
	    			} else {
	    				item.isRoot = true;
	    				item.parent=undefined;
	    			}
	    			itemList.push(item);
	    			itemHash[item.id] = item;
    			}
    		}
        });
    };

    var update = function() {
    	var language = LanguageService.getLanguage();
    	if(!language) return;
        $http.get("data/lang/"+ language.id + "/_words.csv").success(function(response) {
    		var words = CsvService.toObjects(response);
    		for(var i=0; i<words.length; i++) {
    			var id = words[i][0];
    			var item = itemHash[id];
    			if(item) {
	    			item.word = words[i][1];
	    			item.sound =words[i][2]  ? words[i][2] : "data/lang/"+ language.id + "/"+item.id+".mp3";
	    		} else {
	    			$log.warn("No item found for "+id);
	    		}
    		}
            $log.debug("Updated words");
        });
    };

    service.getItemList = function() {
    	var keyList = [];
		$log.debug("node: "+node);
		for(var i=1; i<itemList.length; i++) {
			var item = itemList[i];
			if(item.parent === node.id) {
				keyList.push(item);
			}
		}
		$log.debug("keys: "+keyList);
    	return keyList;
    }

    service.down = function(item) {
    	node = item;
    	update();
    }

    service.up = function() {
    	node = itemHash[node.parent];
    	if(!node) node = {};
    	update();
    }

    service.update = function() {
    	update();
    }

    service.isAtRoot = function() {
    	return !node.parent;
    }

    init();

    return service;
});