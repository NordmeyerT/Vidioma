app.controller('TileController', function ($scope, WordService, $rootScope, $log) {
    var ctrl = this;
    ctrl.update = function() {
    	WordService.update();
    };

    ctrl.getItemList = function() {
    	return WordService.getItemList();
    };

    ctrl.up = function() {
		WordService.up();
    };

    ctrl.down = function(item) {
		WordService.down(item);
    };

    ctrl.isAtRoot = function() {
    	return WordService.isAtRoot();
    }

    ctrl.update();

    return $scope.TileController = this;
});
